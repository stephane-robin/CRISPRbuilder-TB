# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['crisprbuilder_tb']

package_data = \
{'': ['*']}

install_requires = \
['biopython==1.76', 'xlrd>=1.2.0,<2.0.0', 'xmltodict>=0.12.0,<0.13.0']

setup_kwargs = {
    'name': 'crisprbuilder-tb',
    'version': '0.1.7',
    'description': '',
    'long_description': None,
    'author': 'stephane-robin',
    'author_email': 'robin.stephane@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
