__version__ = '0.1.0'
from .__main__ import *
