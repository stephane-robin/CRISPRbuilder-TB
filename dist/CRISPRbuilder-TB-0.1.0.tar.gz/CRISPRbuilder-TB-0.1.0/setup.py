# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['crisprbuilder_tb']

package_data = \
{'': ['*']}

install_requires = \
['biopython>=1.76,<2.0', 'xlrd>=1.2.0,<2.0.0', 'xmltodict>=0.12.0,<0.13.0']

setup_kwargs = {
    'name': 'crisprbuilder-tb',
    'version': '0.1.0',
    'description': 'Collect and annotate Mycobacterium tuberculosis WGS data for CRISPR investigations.',
    'long_description': '# pyMTC\n\n## Purpose of this project:\n\nCollect and annotate Mycobacterium tuberculosis WGS data for CRISPR investigations.\n\n## Requirements:\n\n## Installation :\n\n## How to use this package:\n\n## Description of the different files:\n\nThe index.tex file is a presentation of the project.\n\n## History\n',
    'author': 'stephane-robin',
    'author_email': 'robin.stephane@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/stephane-robin/package_pymtc.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.6.5',
}


setup(**setup_kwargs)
