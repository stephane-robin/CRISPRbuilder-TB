# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['crisprbuilder_tb']

package_data = \
{'': ['*']}

install_requires = \
['biopython>=1.76,<2.0', 'xlrd>=1.2.0,<2.0.0', 'xmltodict>=0.12.0,<0.13.0']

setup_kwargs = {
    'name': 'crisprbuilder-tb',
    'version': '0.1.0',
    'description': 'Collect and annotate Mycobacterium tuberculosis WGS data for CRISPR investigations.',
    'long_description': '# CRISPRbuilder-TB\n------------------\n\n>This **README.md** gives you the gist of the CRISPRbuilder-TB package. Please refer to **crisprbuilder-tb.md** included in the package for more detailed explanation.    \n\n\n## Purpose of this package\n--------------------------\n\n>Collect and annotate Mycobacterium tuberculosis whole genome sequencing data for CRISPR investigation.    \n\n\n## Requirements\n---------------\n\n>CRISPRbuilder-TB needs the following dependencies to work:\n\n* python = "^3.7"\n* xlrd = "^1.2.0"\n* openpyxl = "^3.0.3"\n* xmltodict = "^0.12.0"\n* biopython = "^1.76"\n* datetime = "^4.3"\n* parallel-fastq-dump\n* balstn+\n\n>These different versions are automatically downloaded when installing the CRISPRbuilder-TB package.    \n\n\n## Installation\n---------------\n\n>Install the package by writing in the command prompt: `pip3 install CRISPRbuilder-TB`.    \n\n\n## How to use this package\n--------------------------\n\n>The most often common instruction for this package is: `python3 CRISPRbuilder-TB --collect {SRA_reference}`.\n\nSee the attached **criprbuilder-tb.md** for a comprehensive explanation.    \n\n\n## History\n----------\n\nThe current version is 1.0\n',
    'author': 'stephane-robin',
    'author_email': 'robin.stephane@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/stephane-robin/package_pymtc.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.6.5',
}


setup(**setup_kwargs)
