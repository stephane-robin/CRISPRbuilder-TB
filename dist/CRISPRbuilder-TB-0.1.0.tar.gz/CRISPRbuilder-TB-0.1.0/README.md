# pyMTC

## Purpose of this project:

Collect and annotate Mycobacterium tuberculosis WGS data for CRISPR investigations.

## Requirements:

## Installation :

## How to use this package:

## Description of the different files:

The index.tex file is a presentation of the project.

## History
